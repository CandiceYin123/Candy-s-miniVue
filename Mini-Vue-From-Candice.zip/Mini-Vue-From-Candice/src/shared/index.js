export const extend=Object.assign;
